/*<<dependency*/
define("com_viz_ext_shake-src/js/flow", [ "com_viz_ext_shake-src/js/module" ], function(moduleFunc) {
/*dependency>>*/
    var flowRegisterFunc = function(){
		var flow = sap.viz.extapi.Flow.createFlow({
			id : 'com.viz.ext.shake',
			name : 'Shake Container',
			dataModel : 'sap.viz.api.data.CrosstableDataset',
			type : 'BorderSVGFlow'
		});
		var element  = sap.viz.extapi.Flow.createElement({
			id : 'com.viz.ext.module.Shake',
			name : 'Shake Module',
		});
		element.implement('sap.viz.elements.common.BaseGraphic', moduleFunc);
		/*Feeds Definition*/
		//ds1: City, Year
		var ds1 = {
		    "id": "com.viz.ext.module.Shake.DS1",
		    "name": "X Axis",
		    "type": "Dimension",
		    "min": 1,
		    "max": 2,
		    "aaIndex": 1,
		    "minStackedDims": 1,
		    "maxStackedDims": Infinity
		};
		//ms1: Margin, Quantity sold, Sales revenue
		var ms1 = {
		    "id": "com.viz.ext.module.Shake.MS1",
		    "name": "Y Axis",
		    "type": "Measure",
		    "min": 1,
		    "max": Infinity,
		    "mgIndex": 1
		};
		element.addFeed(ds1);
		element.addFeed(ms1);
		flow.addElement({
			'element':element,
			'propertyCategory' : 'Shake Module'
		});
		sap.viz.extapi.Flow.registerFlow(flow);
    };
    flowRegisterFunc.id = 'com.viz.ext.shake';
    return {
        id : flowRegisterFunc.id,
        init : flowRegisterFunc
    };
});